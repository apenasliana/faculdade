Arquivo zip gerado em: 27/02/2022 13:01:47 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Várias possibilidades